"""
This module makes some functions of the SPAMS library usable
with numpy and scipy.
"""

import spams_wrap
import numpy as np
import scipy.sparse as ssp

##################################################
# tool to handle param structures
def __param_struct(param_list,params_in):
    params = []
    for (k,defv) in param_list:
        if k in params_in:
            p = params_in[k]
        else:
            p = defv
        if p == None:
            raise ValueError("ERROR: param %s must be initialized" %k)
        params.append(p)
    return params

###########  linalg ##############

def Sort(X,mode=True):
    """
    Usage:   Y =Sort(X);
    
    Name: Sort
    
    Description: sort the elements of X using quicksort
    
    Inputs: X:  float or double vector of size n
    
    Output: Y: float or double  vector of size n
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    y = np.copy(X)
    spams_wrap.sort(y,mode)
    return y


def CalcAAt(A):
    """
    Usage:   AAt =CalcAAt(A);
    
    Name: CalcAAt
    
    Description: Compute efficiently AAt = A*A', when A is sparse 
    and has a lot more columns than rows. In some cases, it is
    up to 20 times faster than the equivalent Matlab expression
    AAt=A*A';
    
    Inputs: A:  float or double sparse m x n matrix   
    
    Output: AAt: float or double m x m matrix 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    if  A.ndim != 2:
        raise ValueError("Not a matrix")
    m = A.shape[0]
    AAt = np.empty((m,m),dtype=A.dtype,order="FORTRAN")
    spams_wrap.AAt(A,AAt)
    return AAt

def CalcXAt(X,A):
    """
    Usage:   XAt =CalcXAt(X,A);
    
    Name: CalcXAt
    
    Description: Compute efficiently XAt = X*A', when A is sparse and has a 
    lot more columns than rows. In some cases, it is up to 20 times 
    faster than the equivalent Matlab expression XAt=X*A';
    
    Inputs: X:  float or double m x n matrix
    A:  float or double sparse p x n matrix   
    
    Output: XAt: float or double m x p matrix 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    if  A.ndim != 2:
        raise ValueError("Not a matrix")
    m = X.shape[0]
    n = A.shape[0]
    XAt = np.empty((m,n),dtype=A.dtype,order="FORTRAN")
    spams_wrap.XAt(A,X,XAt)
    return XAt

def mult(X,Y,transX = False, transY = False):
    if transX:
        m = X.shape[1]
    else:
        m = X.shape[0]
    if transY:
        n = Y.shape[0]
    else:
        n = Y.shape[1]
    XY = np.empty((m,n),dtype=X.dtype,order="FORTRAN")
    spams_wrap.mult(X,Y,XY,transX,transY,1,0)
    return XY

def CalcXY(X,Y):
    """
    Usage:   Z =CalcXY(X,Y);
    
    Name: CalcXY
    
    Description: Compute Z=XY using the BLAS library used by SPAMS.
    
    Inputs: X:  float or double m x n matrix
    Y:  float or double n x p matrix   
    
    Output: Z: float or double m x p matrix 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    return mult(X,Y,False,False)

def CalcXYt(X,Y):
    """
    Usage:   Z =CalcXYt(X,Y);
    
    Name: CalcXYt
    
    Description: Compute Z=XY' using the BLAS library used by SPAMS.
    
    Inputs: X:  float or double m x n matrix
    Y:  float or double p x n matrix   
    
    Output: Z: float or double m x p matrix 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    return mult(X,Y,False,True)

def CalcXtY(X,Y):
    """
    Usage:   Z =CalcXtY(X,Y);
    
    Name: CalcXtY
    
    Description: Compute Z=X'Y using the BLAS library used by SPAMS.
    
    Inputs: X:  float or double n x m matrix
    Y:  float or double n x p matrix   
    
    Output: Z: float or double m x p matrix 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    return mult(X,Y,True,False)

def Bayer(X,offset):
    """
    Usage:   Y =Bayer(X,offset);
    
    Name: Bayer
    
    Description:  applies a Bayer pattern to an image X.
    There are four possible offsets.
    
    
    Inputs: X:  float or double m x n matrix   
    offset: scalar, 0,1,2 or 3   
    
    Output: Y: float or double m x m matrix 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    y = np.copy(X)
    spams_wrap.applyBayerPattern(y,offset)
    return y

def ConjGrad(A,b,x0 = None,tol = 1e-10,itermax = None):
    """
    Usage:   x =ConjGrad(A,b,x0,tol,itermax)
    
    Name: ConjGrad
    
    Description: Conjugate gradient algorithm, sometimes faster than the 
    equivalent Matlab function pcg. In order to solve Ax=b;
    
    Inputs: A:  float or double square n x n matrix. HAS TO BE POSITIVE DEFINITE
    b:  float or double vector of length n.
    x0: float or double vector of length n. (optional) initial guess.
    tol: (optional) tolerance.
    itermax: (optional) maximum number of iterations.
    
    Output: x: float or double vector of length n.
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    n = A.shape[1]
    if x0 == None:
        x = np.zeros((n),dtype = np.float64)
    else:
        x = np.copy(x0)
    if itermax == None:
        itermax = n
    spams_wrap.conjugateGradient(A,b,x,tol,itermax)
    return x

def InvSym(A):
    """
    Usage:   B =InvSym(A);
    
    Name: InvSym
    
    Description: returns the inverse of a symmetric matrix A
    
    Inputs: A:  float or double n x n matrix   
    
    Output: B: float or double n x n matrix 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    B = np.copy(A)
    spams_wrap.invSym(B)
    return B

def Normalize(A):
    """
    Usage:   Y =Normalize(X);
    
    Name: Normalize
    
    Description: rescale the columns of X so that they have
    unit l2-norm.
    
    Inputs: X:  float or double m x n matrix   
    
    Output: Y: float or double m x n matrix 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    B = np.copy(A)
    spams_wrap.normalize(B)
    return B

########### END linalg ##############
##################################################

###########  decomp ##################

def  SparseProject(U,param):
    """
    Usage:  V=SparseProject(U,param);
    
    Name: SparseProject
    
    Description: SparseProject solves various optimization 
    problems, including projections on a few convex sets.
    It aims at addressing the following problems
    for all columns u of U in parallel
    1) when param['mode']=1 (projection on the l1-ball)
    min_v ||u-v||_2^2  s.t.  ||v||_1 <= thrs
    2) when param['mode']=2
    min_v ||u-v||_2^2  s.t. ||v||_2^2 + lamuda1||v||_1 <= thrs
    3) when param['mode']=3
    min_v ||u-v||_2^2  s.t  ||v||_1 + 0.5lamuda1||v||_2^2 <= thrs 
    4) when param['mode']=4
    min_v 0.5||u-v||_2^2 + lamuda1||v||_1  s.t  ||v||_2^2 <= thrs
    5) when param['mode']=5
    min_v 0.5||u-v||_2^2 + lamuda1||v||_1 +lamuda2 FL(v) + ... 
    0.5lamuda_3 ||v||_2^2
    where FL denotes a "fused lasso" regularization term.
    6) when param['mode']=6
    min_v ||u-v||_2^2 s.t lamuda1||v||_1 +lamuda2 FL(v) + ...
    0.5lamuda3||v||_2^2 <= thrs
    
    When param['pos']=true and param.mode <= 4,
    it solves the previous problems with positivity constraints 
    
    Inputs: U:  float or double m x n matrix   (input signals)
    m is the signal size
    n is the number of signals to project
    param: struct
    param['thrs'] (parameter)
    param['lambda1'] (parameter)
    param['lambda2'] (parameter)
    param['lambda3'] (parameter)
    param['mode'] (see above)
    param['pos'] (optional, false by default)
    param['numThreads'] (optional, number of threads for exploiting
    multi-core / multi-cpus. By default, it takes the value -1,
    which automatically selects all the available CPUs/cores).
    
    Output: V: float or double m x n matrix (output matrix)
    
    Note: this function admits a few experimental usages, which have not
    been extensively tested:
    - single precision setting 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    m = U.shape[0];
    n = U.shape[1];
    paramlist = [('thrs',1.0),('mode',1),('lambda1',0.0),('lambda2',0.0),('lambda3',0.0),('pos',0),('numThreads',-1)]
    V = np.empty((m,n),dtype=U.dtype,order="FORTRAN")
    params = __param_struct(paramlist,param)
    spams_wrap.sparseProject(U,V,*params);
    return V

# A = Lasso(X,D,param,return_reg_path = False):
# (A,path) = Lasso(X,D,param,return_reg_path = True):
# A = Lasso(X,Q,q,param,return_reg_path = False):
# (A,path) = Lasso(X,Q,q,param,return_reg_path = True):
def Lasso(*args,**opt):
    """
    Usage:  [A [path]]=Lasso(X,D,param);
    or:    [A [path]]=Lasso(X,Q,q,param);
    
    Name: Lasso
    
    Description: Lasso is an efficient implementation of the
    homotopy-LARS algorithm for solving the Lasso. 
    
    if the function is called this way [A [path]]=Lasso(X,D,param),
    it aims at addressing the following problems
    for all columns x of X, it computes one column alpha of A
    that solves
    1) when param['mode']=0
    min_{alpha} ||x-Dalpha||_2^2 s.t. ||alpha||_1 <= lambda
    2) when param['mode']=1
    min_{alpha} ||alpha||_1 s.t. ||x-Dalpha||_2^2 <= lambda
    3) when param['mode']=2
    min_{alpha} 0.5||x-Dalpha||_2^2 + lambda||alpha||_1 +0.5 lambda2||alpha||_2^2
    
    if the function is called this way [A [path]]=Lasso(X,Q,q,param),
    it solves the above optimisation problem, when Q=D'D and q=D'x.
    
    Possibly, when param['pos']=true, it solves the previous problems
    with positivity constraints on the vectors alpha
    
    Inputs: X:  float or double m x n matrix   (input signals)
    m is the signal size
    n is the number of signals to decompose
    D:  float or double m x p matrix   (dictionary)
    p is the number of elements in the dictionary
    param: struct
    param['lambda']  (parameter)
    param['lambda2']  (optional parameter for solving the Elastic-Net)
    for mode=0 and mode=1, it adds a ridge on the Gram Matrix
    param['L'] (optional), maximum number of steps of the homotopy algorithm (can
    be used as a stopping criterion)
    param['pos'] (optional, adds non-negativity constraints on the
    coefficients, false by default)
    param['mode'] (see above, by default: 2)
    param['numThreads'] (optional, number of threads for exploiting
    multi-core / multi-cpus. By default, it takes the value -1,
    which automatically selects all the available CPUs/cores).
    param['cholesky'] (optional, default false),  choose between Cholesky 
    implementation or one based on the matrix inversion Lemma
    param['ols'] (optional, default false), perform an orthogonal projection
    before returning the solution.
    param['max_length_path'] (optional) maximum length of the path.
    
    Output: A: float or double sparse p x n matrix (output coefficients)
    path: optional,  returns the regularisation path for the first signal
    
    Note: this function admits a few experimental usages, which have not
    been extensively tested:
    - single precision setting (even though the output alpha is float or double 
    precision)
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    paramlist = [('L', -1),('lambda', None),('lambda2', 0.),
                 ('mode', spams_wrap.PENALTY),('pos', False),('ols', False),('numThreads', -1),
                 ('length_path', -1),('verbose',True),('cholesky', False)]
    # Note : 'L' and 'length_path' default to -1 so that their effective default values
    # will be set in spams.h
    if 'return_reg_path' in opt:
        return_reg_path = opt['return_reg_path']
    else:
        return_reg_path = False
    q = None
    if(len(args) == 3):
        param = args[2]
    elif (len(args) == 4):
        param = args[3]
        q = args[2]
    else:
        raise ValueError("Lasso : bad nb of arguments")
    X = args[0]
    D = args[1]
    params = __param_struct(paramlist,param)
    path = None
    if(q != None):
        if return_reg_path:
            ((indptr,indices,data,shape),path) = spams_wrap.lassoQq(X,D,q,0,return_reg_path,*params)
        else:
            (indptr,indices,data,shape) = spams_wrap.lassoQq(X,D,q,0,return_reg_path,*params)
    else:
        if return_reg_path:
            ((indptr,indices,data,shape),path) = spams_wrap.lassoD(X,D,0,return_reg_path,*params)
        else:
            (indptr,indices,data,shape) = spams_wrap.lassoD(X,D,0,return_reg_path,*params)
    alpha = ssp.csc_matrix((data,indices,indptr),shape)
    if return_reg_path:
        return (alpha,path)
    else:
        return alpha

###########  END decomp ##############
##################################################

###########  prox ##################
# W = FistaFlat(Y,X,W0,param,return_optim_info = False)
# (W,optim_info) = FistaFlat(Y,X,W0,param,return_optim_info = True)
def FistaFlat(Y,X,W0,param,return_optim_info = False):
    """
    Usage: W=FistaFlat(Y,X,W0,param);
    
    Name: FistaFlat
    
    Description: FistaFlat solves sparse regularized problems.
    X is a design matrix of size m x p
    X=[x^1,...,x^n]', where the x_i's are the rows of X
    Y=[y^1,...,y^n] is a matrix of size m x n
    It implements the algorithms FISTA, ISTA and subgradient descent.
    
    - if param['loss']='square' and param.regul is a regularization function for vectors,
    the entries of Y are real-valued,  W = [w^1,...,w^n] is a matrix of size p x n
    For all column y of Y, it computes a column w of W such that
    w = argmin 0.5||y- X w||_2^2 + lambda psi(w)
    
    - if param['loss']='square' and param.regul is a regularization function for matrices
    the entries of Y are real-valued,  W is a matrix of size p x n. 
    It computes the matrix W such that
    W = argmin 0.5||Y- X W||_F^2 + lambda psi(W)
    
    - param['loss']='square-missing' : same as param.loss='square', but handles missing data
    represented by NaN (not a number) in the matrix Y
    
    - if param['loss']='logistic' and param.regul is a regularization function for vectors,
    the entries of Y are either -1 or +1, W = [w^1,...,w^n] is a matrix of size p x n
    For all column y of Y, it computes a column w of W such that
    w = argmin (1/m)sum_{j=1}^m log(1+e^(-y_j x^j' w)) + lambda psi(w),
    where x^j is the j-th row of X.
    
    - if param['loss']='logistic' and param.regul is a regularization function for matrices
    the entries of Y are either -1 or +1, W is a matrix of size p x n
    W = argmin sum_{i=1}^n(1/m)sum_{j=1}^m log(1+e^(-y^i_j x^j' w^i)) + lambda psi(W)
    
    - if param['loss']='multi-logistic' and param.regul is a regularization function for vectors,
    the entries of Y are in {0,1,...,N} where N is the total number of classes
    W = [W^1,...,W^n] is a matrix of size p x Nn, each submatrix W^i is of size p x N
    for all submatrix WW of W, and column y of Y, it computes
    WW = argmin (1/m)sum_{j=1}^m log(sum_{j=1}^r e^(x^j'(ww^j-ww^{y_j}))) + lambda sum_{j=1}^N psi(ww^j),
    where ww^j is the j-th column of WW.
    
    - if param['loss']='multi-logistic' and param.regul is a regularization function for matrices,
    the entries of Y are in {0,1,...,N} where N is the total number of classes
    W is a matrix of size p x N, it computes
    W = argmin (1/m)sum_{j=1}^m log(sum_{j=1}^r e^(x^j'(w^j-w^{y_j}))) + lambda psi(W)
    where ww^j is the j-th column of WW.
    
    - param['loss']='cur' : useful to perform sparse CUR matrix decompositions, 
    W = argmin 0.5||Y-X*W*X||_F^2 + lambda psi(W)
    
    
    The function psi are those used by mexProximalFlat (see documentation)
    
    This function can also handle intercepts (last row of W is not regularized),
    and/or non-negativity constraints on W, and sparse matrices for X
    
    Inputs: Y:  float or double dense m x n matrix
    X:  float or double dense or sparse m x p matrix   
    W0:  float or double dense p x n matrix or p x Nn matrix (for multi-logistic loss)
    initial guess
    param: struct
    param['loss'] (choice of loss, see above)
    param['regul'] (choice of regularization, see function mexProximalFlat)
    param['lambda'] (regularization parameter)
    param['lambda2'] (optional, regularization parameter, 0 by default)
    param['lambda3'] (optional, regularization parameter, 0 by default)
    param['verbose'] (optional, verbosity level, false by default)
    param['intercept'] (optional, last row of U is not regularized,
    false by default)
    param['pos'] (optional, adds positivity constraints on the
    coefficients, false by default)
    param['numThreads'] (optional, number of threads for exploiting
    multi-core / multi-cpus. By default, it takes the value -1,
    which automatically selects all the available CPUs/cores).
    param['max_it'] (optional, maximum number of iterations, 100 by default)
    param['tol'] (optional, tolerance for stopping criteration, which is a relative duality gap
    if it is available, or a relative change of parameters).
    param['gamma'] (optional, multiplier for increasing the parameter L in fista, 1.5 by default)
    param['L0'] (optional, initial parameter L in fista, 0.1 by default, should be small enough)
    param['fixed_step'] (deactive the line search for L in fista and use param.L0 instead)
    param['compute_gram'] (optional, pre-compute X^TX, false by default).
    param['intercept'] (optional, do not regularize last row of W, false by default).
    param['ista'] (optional, use ista instead of fista, false by default).
    param['subgrad'] (optional, if not param.ista, use subradient descent instead of fista, false by default).
    param['a,'] param.b (optional, if param.subgrad, the gradient step is a/(t+b)
    also similar options as mexProximalFlat
    
    the function also implements the ADMM algorithm via an option param['admm']=true. It is not documented
    and you need to look at the source code to use it.
    
    Output:  W:  float or double dense p x n matrix or p x Nn matrix (for multi-logistic loss)
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """


    paramlist = [("numThreads" ,-1), ("max_it" , 1000),('L0',1.0),
                 ('fixed_step',False),
                 ('gamma',1.5),('lambda',1.0),('delta',1.0),('lambda2',0.),
                 ('lambda3',0.),('a',1.0),('b',0.),('c',1.0),('tol',0.000001),
                 ('it0',100),('max_iter_backtracking',1000),
                 ('compute_gram',False),('lin_admm',False),('admm',False),
                 ('intercept',False),('resetflow',False),('regul',""),
                 ('loss',""),('verbose',False),('pos',False),
                 ('clever',False),('log',False),('ista',False),
                 ('subgrad',False),('logName',''),('is_inner_weights',False),
                 ('inner_weights',np.array([0.])),('eval',False),('size_group',1),
                 ('sqrt_step',True),('transpose',False)]
    params = __param_struct(paramlist,param)
#    W = np.empty((W0.shape[0],W0.shape[1]),dtype=W0.dtype,order="FORTRAN")
    W = np.zeros((W0.shape[0],W0.shape[1]),dtype=W0.dtype,order="FORTRAN")
    optim_info = spams_wrap.fistaFlat(Y,X,W0,W,*params)
    if(return_optim_info != None):
        return(W,optim_info)
    else:
        return W

def ProximalFlat(alpha0,param,return_val_loss = False):
    """
    Usage:   alpha=ProximalFlat(U,param);
    
    Name: ProximalFlat
    
    Description: ProximalFlat computes proximal operators. Depending
    on the value of param['regul,'] it computes 
    
    Given an input matrix U=[u^1,\ldots,u^n], it computes a matrix 
    V=[v^1,\ldots,v^n] such that
    if one chooses a regularization functions on vectors, it computes
    for each column u of U, a column v of V solving
    if param['regul']='l0'
    argmin 0.5||u-v||_2^2 + lambda||v||_0
    if param['regul']='l1'
    argmin 0.5||u-v||_2^2 + lambda||v||_1
    if param['regul']='l2'
    argmin 0.5||u-v||_2^2 + lambda||v||_2^2
    if param['regul']='elastic-net'
    argmin 0.5||u-v||_2^2 + lambda||v||_1 + lambda_2||v||_2^2
    if param['regul']='fused-lasso'
    argmin 0.5||u-v||_2^2 + lambda FL(v) + ...
    ...  lambda_2||v||_1 + lambda_3||v||_2^2
    if param['regul']='linf'
    argmin 0.5||u-v||_2^2 + lambda||v||_inf
    if param['regul']='l2-not-squared'
    argmin 0.5||u-v||_2^2 + lambda||v||_2
    if param['regul']='group-lasso-l2'  
    argmin 0.5||u-v||_2^2 + lambda sum_g ||v_g||_2 
    where the groups are consecutive entries of v of size param['group_size'] 
    if param['regul']='group-lasso-linf'
    argmin 0.5||u-v||_2^2 + lambda sum_g ||v_g||_inf
    if param['regul']='sparse-group-lasso-l2'  
    argmin 0.5||u-v||_2^2 + lambda sum_g ||v_g||_2 + lambda_2 ||v||_1
    where the groups are consecutive entries of v of size param['group_size'] 
    if param['regul']='sparse-group-lasso-linf'
    argmin 0.5||u-v||_2^2 + lambda sum_g ||v_g||_inf + lambda_2 ||v||_1
    if param['regul']='trace-norm-vec' 
    argmin 0.5||u-v||_2^2 + lambda ||mat(v)||_* 
    where mat(v) has param['group_size'] rows
    
    if one chooses a regularization function on matrices
    if param['regul']='l1l2',  V= 
    argmin 0.5||U-V||_F^2 + lambda||V||_{1/2}
    if param['regul']='l1linf',  V= 
    argmin 0.5||U-V||_F^2 + lambda||V||_{1/inf}
    if param['regul']='l1l2+l1',  V= 
    argmin 0.5||U-V||_F^2 + lambda||V||_{1/2} + lambda_2||V||_{1/1}
    if param['regul']='l1linf+l1',  V= 
    argmin 0.5||U-V||_F^2 + lambda||V||_{1/inf} + lambda_2||V||_{1/1}
    if param['regul']='l1linf+row-column',  V= 
    argmin 0.5||U-V||_F^2 + lambda||V||_{1/inf} + lambda_2||V'||_{1/inf}
    if param['regul']='trace-norm',  V= 
    argmin 0.5||U-V||_F^2 + lambda||V||_*
    if param['regul']='rank',  V= 
    argmin 0.5||U-V||_F^2 + lambda rank(V)
    if param['regul']='none',  V= 
    argmin 0.5||U-V||_F^2 
    
    for all these regularizations, it is possible to enforce non-negativity constraints
    with the option param['pos,'] and to prevent the last row of U to be regularized, with
    the option param['intercept']
    
    Inputs: U:  float or double m x n matrix   (input signals)
    m is the signal size
    param: struct
    param['lambda']  (regularization parameter)
    param['regul'] (choice of regularization, see above)
    param['lambda2']  (optional, regularization parameter)
    param['lambda3']  (optional, regularization parameter)
    param['verbose'] (optional, verbosity level, false by default)
    param['intercept'] (optional, last row of U is not regularized,
    false by default)
    param['transpose'] (optional, transpose the matrix in the regularizaiton function)
    param['group_size'] (optional, for regularization functions assuming a group
    structure)
    param['pos'] (optional, adds positivity constraints on the
    coefficients, false by default)
    param['numThreads'] (optional, number of threads for exploiting
    multi-core / multi-cpus. By default, it takes the value -1,
    which automatically selects all the available CPUs/cores).
    
    Output: alpha: float or double m x n matrix (output coefficients)
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    paramlist = [("numThreads" ,-1), ('lambda',1.0),('lambda2',0.),
                 ('lambda3',0.),('intercept',False),('resetflow',False),
                 ('regul',""),('verbose',False),('pos',False),
                 ('clever',True),('eval',return_val_loss),
                 ('size_group',1),('transpose',False)]
    params = __param_struct(paramlist,param)
    alpha = np.zeros((alpha0.shape[0],alpha0.shape[1]),dtype=alpha0.dtype,order="FORTRAN")
    val_loss = spams_wrap.proximalFlat(alpha0,alpha,*params)
    if return_val_loss:
        return(alpha,val_loss)
    else:
        return alpha

###########  END prox ##############
##################################################

###########  dictLearn ##################
def __allTrainDL(X,param,return_model,model,in_memory):
    paramlist = [("D",np.array([[],[]],dtype=np.float64,order="FORTRAN")),("numThreads" ,-1),("batchsize", -1),
                 ("K", -1),('lambda', None),('lambda2', 10e-10),
                 ('iter',-1),('t0',1e-5),('mode',spams_wrap.PENALTY),
                 ('posAlpha',False),('posD',False),('expand',False),
                 ('modeD',spams_wrap.L2),('whiten',False),('clean',True),
                 ('verbose',True),('gamma1',0.),('gamma2',0.),
                 ('rho',1.0),('iter_updateD',1.),('stochastic_deprecated',False),
                 ('modeParam',0),('batch',False),('log_deprecated',False),
                 ('logName','')
                 ]
    params = __param_struct(paramlist,param)
    if model == None:
        m_A = np.array([[],[]],dtype=np.float64,order="FORTRAN")
        m_B = np.array([[],[]],dtype=np.float64,order="FORTRAN")
        m_iter = 0
    else:
        m_A = model['A']
        m_B = model['B']
        m_iter = int(model['iter'])
    x = spams_wrap.alltrainDL(X,in_memory,0,0,0,return_model,m_A,m_B,m_iter,*params)
    if return_model:
        (D,A,B,iter) = x
        model = {'A' : A, 'B' : B, 'iter' : iter[0]}
        return (D,model)
    else:
        return x

def TrainDL(X,param,return_model= False,model= None):
    """
    Usage:   [D [model]]=TrainDL(X,param[,model]);
    model is optional
    
    Name: TrainDL
    
    Description: TrainDL is an efficient implementation of the
    dictionary learning technique presented in
    
    "Online Learning for Matrix Factorization and Sparse Coding"
    by Julien Mairal, Francis Bach, Jean Ponce and Guillermo Sapiro
    arXiv:0908.0050
    
    "Online Dictionary Learning for Sparse Coding"      
    by Julien Mairal, Francis Bach, Jean Ponce and Guillermo Sapiro
    ICML 2009.
    
    Note that if you use param['mode']=1 or 2, if the training set has a
    reasonable size and you have enough memory on your computer, you 
    should use TrainDL_Memory instead.
    
    
    It addresses the dictionary learning problems
    1) if param['mode']=0
    min_{D in C} (1/n) sum_{i=1}^n (1/2)||x_i-Dalpha_i||_2^2  s.t. ...
    ||alpha_i||_1 <= lambda
    2) if param['mode']=1
    min_{D in C} (1/n) sum_{i=1}^n  ||alpha_i||_1  s.t.  ...
    ||x_i-Dalpha_i||_2^2 <= lambda
    3) if param['mode']=2
    min_{D in C} (1/n) sum_{i=1}^n (1/2)||x_i-Dalpha_i||_2^2 + ... 
    lambda||alpha_i||_1 + lambda_2||alpha_i||_2^2
    4) if param['mode']=3, the sparse coding is done with OMP
    min_{D in C} (1/n) sum_{i=1}^n (1/2)||x_i-Dalpha_i||_2^2  s.t. ... 
    ||alpha_i||_0 <= lambda
    5) if param['mode']=4, the sparse coding is done with OMP
    min_{D in C} (1/n) sum_{i=1}^n  ||alpha_i||_0  s.t.  ...
    ||x_i-Dalpha_i||_2^2 <= lambda
    
    %     C is a convex set verifying
    1) if param['modeD']=0
    C={  D in Real^{m x p}  s.t.  forall j,  ||d_j||_2^2 <= 1 }
    2) if param['modeD']=1
    C={  D in Real^{m x p}  s.t.  forall j,  ||d_j||_2^2 + ... 
    gamma1||d_j||_1 <= 1 }
    3) if param['modeD']=2
    C={  D in Real^{m x p}  s.t.  forall j,  ||d_j||_2^2 + ... 
    gamma1||d_j||_1 + gamma2 FL(d_j) <= 1 }
    4) if param['modeD']=3
    C={  D in Real^{m x p}  s.t.  forall j,  (1-gamma1)||d_j||_2^2 + ... 
    gamma1||d_j||_1 <= 1 }

    
    Potentially, n can be very large with this algorithm.
    
    Inputs: X:  float or double m x n matrix   (input signals)
    m is the signal size
    n is the number of signals to decompose
    param: struct
    param['D:'] (optional) float or double m x p matrix   (dictionary)
    p is the number of elements in the dictionary
    When D is not provided, the dictionary is initialized 
    with random elements from the training set.
    param['lambda']  (parameter)
    param['lambda2']  (optional, by default 0)
    param['iter'] (number of iterations).  If a negative number is 
    provided it will perform the computation during the
    corresponding number of seconds. For instance param['iter']=-5
    learns the dictionary during 5 seconds.
    param['mode'] (optional, see above, by default 2) 
    param['posAlpha'] (optional, adds positivity constraints on the
    coefficients, false by default, not compatible with 
    param['mode'] =3,4)
    param['modeD'] (optional, see above, by default 0)
    param['posD'] (optional, adds positivity constraints on the 
    dictionary, false by default, not compatible with 
    param['modeD']=2)
    param['gamma1'] (optional parameter for param.modeD >= 1)
    param['gamma2'] (optional parameter for param.modeD = 2)
    param['batchsize'] (optional, size of the minibatch, by default 
    512)
    param['modeParam'] (optimization mode).
    1) if param['modeParam']=0, the optimization uses the 
    parameter free strategy of the ICML paper
    2) if param['modeParam']=1, the optimization uses the 
    parameters rho as in arXiv:0908.0050
    3) if param['modeParam']=2, the optimization uses exponential 
    decay weights with updates of the form 
    A_{t} <- rho A_{t-1} + alpha_t alpha_t^T
    param['rho'] (optional) tuning parameter (see paper arXiv:0908.0050)
    param['clean'] (optional, true by default. prunes 
    automatically the dictionary from unused elements).
    param['numThreads'] (optional, number of threads for exploiting
    multi-core / multi-cpus. By default, it takes the value -1,
    which automatically selects all the available CPUs/cores).
    
    Output: 
    param['D:'] float or double m x p matrix   (dictionary)
    
    Note: this function admits a few experimental usages, which have not
    been extensively tested:
    - single precision setting 
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    return __allTrainDL(X,param,return_model,model,False)
def TrainDL_Memory(X,param):
    """
    Usage:   [D]=mexTrainDL(X,param);
    
    Name: TrainDL_Memory
    
    Description: TrainDL_Memory is an efficient but memory consuming 
    variant of the dictionary learning technique presented in
    
    "Online Learning for Matrix Factorization and Sparse Coding"
    by Julien Mairal, Francis Bach, Jean Ponce and Guillermo Sapiro
    arXiv:0908.0050
    
    "Online Dictionary Learning for Sparse Coding"      
    by Julien Mairal, Francis Bach, Jean Ponce and Guillermo Sapiro
    ICML 2009.
    
    Contrary to the approaches above, the algorithm here 
    does require to store all the coefficients from all the training
    signals. For this reason this variant can not be used with large
    training sets, but is more efficient than the regular online
    approach for training sets of reasonable size.
    
    It addresses the dictionary learning problems
    1) if param['mode']=1
    min_{D in C} (1/n) sum_{i=1}^n  ||alpha_i||_1  s.t.  ...
    ||x_i-Dalpha_i||_2^2 <= lambda
    2) if param['mode']=2
    min_{D in C} (1/n) sum_{i=1}^n (1/2)||x_i-Dalpha_i||_2^2 + ... 
    lambda||alpha_i||_1  
    
    C is a convex set verifying
    1) if param['modeD']=0
    C={  D in Real^{m x p}  s.t.  forall j,  ||d_j||_2^2 <= 1 }
    1) if param['modeD']=1
    C={  D in Real^{m x p}  s.t.  forall j,  ||d_j||_2^2 + ... 
    gamma1||d_j||_1 <= 1 }
    1) if param['modeD']=2
    C={  D in Real^{m x p}  s.t.  forall j,  ||d_j||_2^2 + ... 
    gamma1||d_j||_1 + gamma2 FL(d_j) <= 1 }
    
    Potentially, n can be very large with this algorithm.
    
    Inputs: X:  float or double m x n matrix   (input signals)
    m is the signal size
    n is the number of signals to decompose
    param: struct
    param['D:'] (optional) float or double m x p matrix   (dictionary)
    p is the number of elements in the dictionary
    When D is not provided, the dictionary is initialized 
    with random elements from the training set.
    param['lambda']  (parameter)
    param['iter'] (number of iterations).  If a negative number is 
    provided it will perform the computation during the
    corresponding number of seconds. For instance param['iter']=-5
    learns the dictionary during 5 seconds.
    param['mode'] (optional, see above, by default 2) 
    param['modeD'] (optional, see above, by default 0)
    param['posD'] (optional, adds positivity constraints on the 
    dictionary, false by default, not compatible with 
    param['modeD']=2)
    param['gamma1'] (optional parameter for param.modeD >= 1)
    param['gamma2'] (optional parameter for param.modeD = 2)
    param['batchsize'] (optional, size of the minibatch, by default 
    512)
    param['modeParam'] (optimization mode).
    1) if param['modeParam']=0, the optimization uses the 
    parameter free strategy of the ICML paper
    2) if param['modeParam']=1, the optimization uses the 
    parameters rho as in arXiv:0908.0050
    3) if param['modeParam']=2, the optimization uses exponential 
    decay weights with updates of the form 
    A_{t} <- rho A_{t-1} + alpha_t alpha_t^T
    param['rho'] (optional) tuning parameter (see paper arXiv:0908.0050)
    param['clean'] (optional, true by default. prunes 
    automatically the dictionary from unused elements).
    param['numThreads'] (optional, number of threads for exploiting
    multi-core / multi-cpus. By default, it takes the value -1,
    which automatically selects all the available CPUs/cores).
    
    Output: 
    param['D:'] float or double m x p matrix   (dictionary)
    
    Note: this function admits a few experimental usages, which have not
    been extensively tested:
    - single precision setting (even though the output alpha is float or double 
    precision)
    
    Authors : Julien MAIRAL, 2010 (spams, matlab interface and documentation)
             Jean-Paul CHIEZE, 2011 (python interface)
    """

    return __allTrainDL(X,param,False,None,True)

###########  END dictLearn ##############
def im2col_sliding(A,m,n,RGB = False):
    mm = A.shape[0]
    nn = A.shape[1]
    M = m * n
    N =  (mm - m + 1) * (nn -n + 1)
    B = np.empty((M,N),dtype=A.dtype,order="FORTRAN")
    spams_wrap.im2col_sliding(A,B,m,n,RGB)
    return B

##################################################
